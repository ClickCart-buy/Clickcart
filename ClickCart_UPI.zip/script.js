let cart = [];
const cartItems = document.getElementById('items-list');
const cartCount = document.getElementById('cart-count');
const totalPriceEl = document.getElementById('total-price');

function addToCart(product, price) {
    const existing = cart.find(item => item.name === product);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ name: product, price: price, quantity: 1 });
    }
    updateCart();
}

function removeFromCart(product) {
    cart = cart.filter(item => item.name !== product);
    updateCart();
}

function updateCart() {
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
        const div = document.createElement('div');
        div.classList.add('cart-item');
        div.innerHTML = `${item.name} x${item.quantity} - ₹${item.price*item.quantity} <button onclick="removeFromCart('${item.name}')">X</button>`;
        cartItems.appendChild(div);
    });
    cartCount.textContent = cart.length;
    totalPriceEl.textContent = total;
}

function toggleCart() {
    const cartBox = document.getElementById('cart-items');
    cartBox.style.display = cartBox.style.display === 'block' ? 'none' : 'block';
}

document.getElementById('checkoutBtn').onclick = function(e) {
    e.preventDefault();
    if(cart.length === 0){
        alert('Your cart is empty!');
        return;
    }

    let total = cart.reduce((sum, item) => sum + item.price*item.quantity, 0) * 100;

    var options = {
        key: 'YOUR_KEY_ID', // Replace with your Razorpay Key ID
        amount: total,
        currency: 'INR',
        name: 'ClickCart',
        description: 'Purchase from ClickCart',
        handler: function(response){
            alert('Payment Successful! Payment ID: ' + response.razorpay_payment_id);
            cart = [];
            updateCart();
        },
        prefill: {
            name: 'Customer Name',
            email: 'clickcartshopinngs.buy@gmail.com',
            contact: '7708660901'
        },
        theme: {
            color: '#ffb74d'
        }
    };

    var rzp = new Razorpay(options);
    rzp.open();
}